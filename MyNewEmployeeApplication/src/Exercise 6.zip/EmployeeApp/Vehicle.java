package EmployeeApp;

public interface Vehicle {
	
	public Boolean hasVehicle();
}
