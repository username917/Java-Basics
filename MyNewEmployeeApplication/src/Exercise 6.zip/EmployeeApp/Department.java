package EmployeeApp;

public interface Department {

	public String hasDepartment(String dept);
	
}

