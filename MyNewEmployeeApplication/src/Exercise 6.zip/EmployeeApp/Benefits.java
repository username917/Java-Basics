package EmployeeApp;

public interface Benefits {

		public String hasBenefits();
	}

