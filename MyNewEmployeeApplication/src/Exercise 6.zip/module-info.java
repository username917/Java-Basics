/**
 * 
 */
/**
 * @author Kat Sagmaquen
 *
 */
module MyNewEmployeeApplication {
}